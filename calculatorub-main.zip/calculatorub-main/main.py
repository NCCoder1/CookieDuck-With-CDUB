import cdub
#cdub.config() options: "cookieduck", "betteralgebra", "simplecalculator"
cdub.config("cookieduck")
cdub.run(debug = False, host="0.0.0.0",port=80)