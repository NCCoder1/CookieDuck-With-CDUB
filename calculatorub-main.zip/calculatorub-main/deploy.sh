pip install git+https://github.com/Cookieduck-Dev/cdub
python main.py